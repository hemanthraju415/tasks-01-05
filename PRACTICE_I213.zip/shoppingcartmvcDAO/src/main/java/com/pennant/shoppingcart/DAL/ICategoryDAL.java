package com.pennant.shoppingcart.DAL;

import com.pennant.shoppingcart.models.CategoryListModel;

public interface ICategoryDAL {
	public CategoryListModel getCategories();
}
